const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const registeredSchema = new Schema({
    studentRegNo : {
        required : true,
        type : String ,      
    },
    courseTitle : {
        required : true,
        type : String
    },
    contactNo : {
        required : true,
        type : String
    },
    degree : {
        required : true,
        type : String 
    },
    scholarship : {
        required : true,
        type : Boolean 
    },

});
const Registered = mongoose.model('Registered',registeredSchema);
module.exports = Registered;