const express = require('express');
const Controller = require('./controller');
const app = express()
app.use(express.static(__dirname+'/view'))

app.get('/',function (req,res) {
    res.sendFile(__dirname+'/index.html');
})
app.get('/register',function (req,res) {
    var obj = req.query
    var controller = new Controller()
    var valid = controller.validate(obj)
    if(valid) {
        var data = controller.prepareObject(obj)
        controller.saveData(data)
        res.send("<h1>Registration Successful</h1>")
    }
    else {
        res.send("<h1>Registration Failed</h1>")
    }  
})

app.listen(3000)


