const model = require('./model/db');
class Controller {

    validate(obj) {
        var x;
        for (x in obj) {
            if(obj[x]==null||obj[x]==0||obj[x]==undefined||obj[x]=="") {
                return false
            }
        }
        return true
    }

    prepareObject(obj) {
        if(obj.operatingSystems) {
            obj.operatingSystems = true
        }
        if(obj.webEngineering) {
            obj.webEngineering = true
        }
        if(obj.softwareDesign) {
            obj.softwareDesign = true
        }
        if(obj.scholarship) {
            obj.scholarship = true
        }
        return obj
    }
    saveData(obj) {
        model(obj)
    }
}

module.exports = Controller