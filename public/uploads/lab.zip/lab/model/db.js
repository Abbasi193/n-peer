var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";

function saveToDataBase(obj) {
    MongoClient.connect(url,{ useUnifiedTopology: true }, function(err, db) {
        if (err) throw err;
        console.log("Database created!");
        var connect = db.db('registration')
        var students = connect.collection('students')
        students.insertOne(obj, function(err, res) {
            if (err) return err;
            console.log("1 document inserted");
            db.close();
            return true
          });
      });
}
module.exports = saveToDataBase