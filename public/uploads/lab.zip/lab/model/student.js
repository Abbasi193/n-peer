const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const studentSchema = new Schema({
    name : {
        required : true,
        type : String ,      
    },
    regNo : {
        required : true,
        type : String,
        unique:true
    },
    contactNo : {
        required : true,
        type : String
    },
    degree : {
        required : true,
        type : String 
    },
    scholarship : {
        required : true,
        type : Boolean 
    },

});
const Student = mongoose.model('Student',studentSchema);
module.exports = Student;